#doubanbook
---
##介绍

doubanbook是一个爬虫，它实现的功能是爬取豆瓣读书9分榜单

这是一个scrapy实例，用来熟悉掌握scrapy的功能和用法。

##1.0功能
爬取豆瓣读书9分榜单

##用法
在setting.py中修改csv保存的路径，然后运行python main.py



##联系
我的Email: hk2291976@hotmail.com

我的CSDN: [http://blog.csdn.net/hk2291976/](http://blog.csdn.net/hk2291976/)

我的简书：[http://www.jianshu.com/users/30f737ee0051](http://www.jianshu.com/users/30f737ee0051)

我的博客园：[www.cnblogs.com/voidsky/](www.cnblogs.com/voidsky/)
